import requests
from bs4 import BeautifulSoup
import os
import datetime

#URL = "https://www.centrumkultury.cz/event/504975/rudy-linka-one-man-show"
URL = "https://www.centrumkultury.cz/event/509828/tanecni-kurz-2022-a-utery-chlapci"
#URL = "https://www.centrumkultury.cz/event/509895/tanecni-kurz-2022-a-utery-divky"

def get_buy_btn():
	print("requesting buy-btn")
	# Request the page
	page = requests.get(URL)

	# Parse is to beautiful soup
	soup = BeautifulSoup(page.content, "html.parser")
	buy_btn = soup.find("span", {"class": "btn-buy"})
	return buy_btn


def open_browser(buy_btn):
	# If buy button already apperead, open it in browser
	ticket_link = buy_btn.parent["href"]
	os.startfile(ticket_link)


if __name__ == "__main__":
	# Setting the times
	start_time = datetime.datetime(2022, 3, 22, 17, 59, 40)

	while start_time > datetime.datetime.now():
		continue 

	print("Getting tanecni buy-btn quuickly xDd")

	buy_btn = None
	while not buy_btn:
		buy_btn = get_buy_btn()

	if buy_btn:
		open_browser(buy_btn)
